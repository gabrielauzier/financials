# Roadmap

- [x] Configurar autenticação por e-mail e senha, sem tabela de perfis.
- [x] Criar sessão, cadastro, login e proteção das páginas privadas.
- [x] Criar layout responsivo e páginas-placeholder.
- [x] Criar cliente REST, seleção de mocks e formatadores.
- [x] Cobrir os fluxos solicitados com testes automatizados.
- [x] Validar a apresentação em desktop e celular.
- [x] Implementar contrato tipado, mocks e hooks de Contas e Categorias.
- [x] Implementar telas e seletores reutilizáveis de Contas e Categorias.
- [x] Cobrir os novos fluxos com testes e validar desktop e celular.
- [x] Implementar contrato, mock, hooks e tela completa do Extrato.
- [x] Cobrir filtros, formulário, ações inline, lote e responsividade do Extrato.
- [x] Conectar o mock de transações aos mocks de contas e categorias.
- [x] Corrigir datas locais no formulário e nos filtros do Extrato.
- [ ] Completar os testes de interface e ajustar a configuração do projeto.
